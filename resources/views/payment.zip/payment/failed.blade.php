<!DOCTYPE html>
<html>
<head>
    <title>Payment Fail</title>
</head>
<body>
    <h1>Payment Failure!</h1>
    <p>Thank you for your payment. Your transaction is fail.</p>
     <div>Error Message  {{$errormessage}}</div>
     <div>Card Holder Name {{$name_on_card}}</div>
</body>
</html>


