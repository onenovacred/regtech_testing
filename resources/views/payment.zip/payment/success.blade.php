
<!DOCTYPE html>
<html>
<head>
    <title>Payment Success</title>
</head>
<body>
    <h1>Payment Successful!</h1>
    <p>Thank you for your payment. Your transaction was successful.</p>
     <p>Transaction Id {{$transactionId}}</p>
     <p>Amount {{$amount}}</p>
</body>
</html>

